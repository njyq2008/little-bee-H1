文件说明：
ring_cover_prdct_10V3.STL 改进磁头模型，3D打印用
tip-cover_production.stl 传感器护套，3D打印用
ProDoc_current-sense_HMC1041Z_2024-12-09.epro 立创EDA原始档，制板用

主要改动：（1）AD8129-> AD8130，第二级运放->LT1886，对应附近有参数更改，layout微调（反馈镂空）；（2）电源输入部分串联三个二极管吃压降，牺牲效率，满足5V输入使用；（3）MCP1640附近参数微调，适应我义胜买的假货MCP1640（按原参数，义胜货发生震荡，真货不管用原参数还是目前的参数均不会震荡）；（4）传感器部分微调；（5）输出线改50欧匹配。

由于我没有画原理图，直接改的PCB，因此没有对应的原理图，见谅见谅。

原作者链接：
https://github.com/westonb/little-bee-B1

本开源项目受CC-BY-SA-4.0 license限制，请知悉。